<?php

namespace App\Http\Controllers;

use App\Models\Antrian;
use App\Models\Program;
use Illuminate\Http\Request;

class DataController extends Controller
{
    public function tampilan() 
    {
      $data['antrian'] = Antrian::get();
      return view('Tampilan', $data);  
    }

    public  function edit($nik)
    {
        $data['antrian'] = Antrian::find($nik);

        return view('edit', $data);
    }

    public function update(Request $request)
    {
        $update = Antrian::where('nik', $request->nik)->update([
            'nama_pasien' => $request->pasien,
            'jenis_kelamin' => $request->kelamin,
            'no_antrian' => $request->antrian,
            'no_handphone' => $request->no_hp,
            'alamat' => $request->alamat
        ]);

        if($update) return redirect('/Tampilan');
        else return 'gagal update data';
    }
}
