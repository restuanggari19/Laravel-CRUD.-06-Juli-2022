<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pasien | Antrian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<table class="table">
  <thead>
    <tr>
      <th scope="col">NIK</th>
      <th scope="col">Nama Pasien</th>
      <th scope="col">jenis kelamin</th>
      <th scope="col">No Antrian</th>
      <th scope="col">No Handphone</th>
      <th scope="col">Alamat</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
        <?php $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->nik); ?></td>
            <td><?php echo e($data->nama_pasien); ?></td>
            <td><?php echo e($data->jenis_kelamin); ?></td>
            <td><?php echo e($data->no_antrian); ?></td>
            <td><?php echo e($data->no_handphone); ?></td>
            <td><?php echo e($data->alamat); ?></td>
            <td><a href="/edit/<?php echo e($data->nik); ?>">Edit</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\laragon\www\rest-api\resources\views/Tampilan.blade.php ENDPATH**/ ?>